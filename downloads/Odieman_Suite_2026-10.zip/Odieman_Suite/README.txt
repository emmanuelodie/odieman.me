ODIEMAN SUITE — PPS Pro · AMS Pro · VigiWard
============================================
Prepared by Odindo Emmanuel Thomas

Open any tool in Google Chrome or Microsoft Edge. Each tool opens its own
User Guide the first time (Getting Started in the menu), and has a
"data folder" option so everything is saved automatically on this computer.

  Odieman_PPS_Pro.html        Point prevalence surveys of antimicrobial use
  Odieman_AMS_Pro_v4_6.html   Antimicrobial stewardship (AWaRe, DDD/DOT, antibiogram, CRFs, reports)
  VigiWard_v3_6.html          Pharmacovigilance, NCD prescribing audit, TB/HIV aDSM

FOLDERS
  PPS_Data/          Data folder for PPS Pro. Already holds 5 sample surveys
                     (Mar 2024 - Jul 2026) - choose it with "Open data folder".
  AMS_Data/          Empty data folder to choose in AMS Pro (Setup > Data folder).
  VigiWard_Data/     Empty data folder to choose in VigiWard (Hub > Data folder).
  Sample_Data/       Sample files to import into AMS Pro and VigiWard
                     (Jan 2024 - Sep 2026). See each tool's User Guide, section
                     "Practise with the sample data", for the import order.

All sample data is simulated for a fictional "Demo Regional Referral Hospital".
It is not real patient data.
